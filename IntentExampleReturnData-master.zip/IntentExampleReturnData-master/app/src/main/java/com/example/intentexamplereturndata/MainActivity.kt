package com.example.intentexamplereturndata

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    private val FILE_NAME = "MyList"
    private var animalList = ArrayList<String>()
    lateinit var myAdapter: ArrayAdapter<String>
    private val todoList = mutableListOf<String>()

    // REQUEST_CODE can be any value you like, used for identifier
    private val REQUEST_CODE = 123 // MUST BE 0 - 65535

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // Create an instance of getSharedPreferences for retrieve the data
        val sharedPreferences = getSharedPreferences(FILE_NAME, MODE_PRIVATE)
        // Retrieve data using the key, default value is empty string in case no saved data in there
        val tasks = sharedPreferences.getString("todos", "") ?: ""

        if (tasks.isNotEmpty()){

            // Create an instance of Gson
            val gson = Gson()
            // create an object expression that descends from TypeToken
            // and then get the Java Type from that
            val sType = object : TypeToken<List<String>>() { }.type
            // provide the type specified above to fromJson() method
            // this will deserialize the previously saved Json into an object of the specified type (e.g., list)
            val savedTodoList = gson.fromJson<List<String>>(tasks, sType)

            // Clear the list and checkboxes in case there are some items
            animalList.clear()

            // Iterate each item in the list and select the corresponding checkbox
            for (item in savedTodoList) {
                animalList.add(item)
                Log.d(TAG, item)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "OnStart was called")
        // Create an adapter with 3 parameters: activity (this), layout, list
        myAdapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, animalList)
        // set the adapter to listview
        animal_list.adapter = myAdapter

        animal_list.setOnItemLongClickListener { parent, view, position, id ->

            val selectedItem = parent.getItemAtPosition(position).toString()
            Toast.makeText(this, "This is a long press, Deleting $selectedItem", Toast.LENGTH_SHORT).show()

            animalList.removeAt(position)

            myAdapter.notifyDataSetChanged()

            return@setOnItemLongClickListener true

        }
    }

    fun openSecondActivity(view: View){
        // Launch the Second Activity for a result

        // prepare the data to be sent to the second activity

        //Create an Intent object with two parameters: 1) context, 2) class of the activity to launch
        val myIntent = Intent(this, SecondActivity::class.java)

        // put "extras" into the intent for access in the second activity
        myIntent.putExtra("todos", animalList)


        // Start the new Activity with startActivityForResult instead of startActivity
        // you must pass a requestCode unique identifier (see top part of the class)
        startActivityForResult(myIntent, REQUEST_CODE)

    }

    // The results will come back through this method
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK){
            // come back from the second activity

            // extract the data from the intent
            animalList = data!!.getStringArrayListExtra("todos")

            // Do something with the data

        }

    }

    override fun onStop() {
        super.onStop()
        // The activity is about to be destroyed
        Log.d(TAG, "onDestroy was called")

        // Create an instance of getSharedPreferences for edit
        val sharedPreferences = getSharedPreferences(FILE_NAME, MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        for (item in animalList) {
            todoList.add(item)
            Log.d(TAG, item)
        }
        // Create an instance of Gson (make sure to include its dependency first to be able use gson)
        val gson = Gson()
        // toJson() method serializes the specified object into its equivalent Json representation.
        val todoListJson = gson.toJson(todoList)
        // Put the  Json representation, which is a string, into sharedPreferences
        editor.putString("todothings", todoListJson)
        // Apply the changes
        editor.apply()
    }


}
