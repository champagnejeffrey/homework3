package com.example.intentexamplereturndata

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_second.*

class SecondActivity : AppCompatActivity() {

    private val TAG = "SecondActivity"
    private var newlist = ArrayList<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)


        newlist = intent.getStringArrayListExtra("todos")


    }

    fun addItemToListAndReturn(view: View) {
        newlist.add(item_text.text.toString())
        // Need to create an intent to go back
        val myIntent = Intent()
        // Store any extra data in the intent
        myIntent.putExtra("todos", newlist)
        // Set the activity's result to RESULT_OK
        setResult(Activity.RESULT_OK, myIntent)
        finish() // Stops and closes the second activity

    }

    fun addItemDontReturn(view: View) {
        newlist.add(item_text.text.toString())
        item_text.setText("")
    }

    fun cancel(view: View) {
        val myIntent = Intent()
        myIntent.putExtra("todos", intent.getStringArrayListExtra("todos"))
        setResult(Activity.RESULT_OK, myIntent)
        finish()
    }

}
