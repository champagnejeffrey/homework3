package com.example.fragmentanimallistwithinterface


import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.fragment_animal_details.view.*
import kotlinx.android.synthetic.main.fragment_animal_list.view.*

/**
 * A simple [Fragment] subclass.
 */
class AnimalListFragment : Fragment() {

    private val TAG = "AnimalListFragment"
    private val FILE_NAME = "MyList"

    // Create a list of some strings that will be shown in the listview




    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE){
            view!!.saveButon.setOnClickListener {
                val sharePref = activity!!.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
                val doggetter = sharePref.getString("Dog","-") ?: "-"
                if (doggetter == "-") {
                    view!!.dogRating.text = "Rating: 0"
                } else {
                    view!!.dogRating.text = "Rating: $doggetter"
                }

                val catgetter = sharePref.getString("Cat","-") ?: "-"
                if (catgetter == "-") {
                    view!!.catRating.text = "Rating: 0"
                } else {
                    view!!.catRating.text = "Rating: $catgetter"
                }

                val beargetter = sharePref.getString("Bear","-") ?: "-"
                if (beargetter == "-") {
                    view!!.bearRating.text = "Rating: 0"
                } else {
                    view!!.bearRating.text = "Rating: $beargetter"
                }

                val rabbitgetter = sharePref.getString("Rabbit","-") ?: "-"
                if (rabbitgetter == "-") {
                    view!!.rabbitRating.text = "Rating: 0"
                } else {
                    view!!.rabbitRating.text = "Rating: $rabbitgetter"
                }

            }
        } else {
            val sharePref = activity!!.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
            val doggetter = sharePref.getString("Dog","-") ?: "-"
            if (doggetter == "-") {
                view!!.dogRating.text = "Rating: 0"
            } else {
                view!!.dogRating.text = "Rating: $doggetter"
            }

            val catgetter = sharePref.getString("Cat","-") ?: "-"
            if (catgetter == "-") {
                view!!.catRating.text = "Rating: 0"
            } else {
                view!!.catRating.text = "Rating: $catgetter"
            }

            val beargetter = sharePref.getString("Bear","-") ?: "-"
            if (beargetter == "-") {
                view!!.bearRating.text = "Rating: 0"
            } else {
                view!!.bearRating.text = "Rating: $beargetter"
            }

            val rabbitgetter = sharePref.getString("Rabbit","-") ?: "-"
            if (rabbitgetter == "-") {
                view!!.rabbitRating.text = "Rating: 0"
            } else {
                view!!.rabbitRating.text = "Rating: $rabbitgetter"
            }
        }

        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_animal_list, container, false)

        Log.d(TAG, "onCreateView after inflation")

        view.dogbutton1.setOnClickListener {
            Log.d(TAG, "dog")

            // Create an instance of the target fragment
            val myAnimalDetailsFragment = AnimalDetailsFragment()

            // Put the position data into the bundle with a key, then set the bundle to arguments
            val bundle = Bundle()
            bundle.putInt("position", 0)
            myAnimalDetailsFragment.arguments = bundle


            // Check the orientation to inflate the details fragment in an fragment appropriate container
            if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT){
                activity!!.supportFragmentManager.beginTransaction()
                    .replace(R.id.main_container, myAnimalDetailsFragment)
                    .addToBackStack(null)
                    .commit()
            }
            else{
                activity!!.supportFragmentManager.beginTransaction()
                    .replace(R.id.details_container, myAnimalDetailsFragment)
                    .addToBackStack(null)
                    .commit()
            }
        }



        view.catbutton2.setOnClickListener {

            Log.d(TAG, "cat")

            // Create an instance of the target fragment
            val myAnimalDetailsFragment = AnimalDetailsFragment()

            // Put the position data into the bundle with a key, then set the bundle to arguments
            val bundle = Bundle()
            bundle.putInt("position", 1)
            myAnimalDetailsFragment.arguments = bundle


            // Check the orientation to inflate the details fragment in an fragment appropriate container
            if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT){
                activity!!.supportFragmentManager.beginTransaction()
                    .replace(R.id.main_container, myAnimalDetailsFragment)
                    .addToBackStack(null)
                    .commit()
            }
            else{
                activity!!.supportFragmentManager.beginTransaction()
                    .replace(R.id.details_container, myAnimalDetailsFragment)
                    .addToBackStack(null)
                    .commit()
            }
        }

        view.bearbutton3.setOnClickListener {

            Log.d(TAG, "bear")

            // Create an instance of the target fragment
            val myAnimalDetailsFragment = AnimalDetailsFragment()

            // Put the position data into the bundle with a key, then set the bundle to arguments
            val bundle = Bundle()
            bundle.putInt("position", 2)
            myAnimalDetailsFragment.arguments = bundle


            // Check the orientation to inflate the details fragment in an fragment appropriate container
            if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT){
                activity!!.supportFragmentManager.beginTransaction()
                    .replace(R.id.main_container, myAnimalDetailsFragment)
                    .addToBackStack(null)
                    .commit()
            }
            else{
                activity!!.supportFragmentManager.beginTransaction()
                    .replace(R.id.details_container, myAnimalDetailsFragment)
                    .addToBackStack(null)
                    .commit()
            }
        }

        view.rabbitbutton4.setOnClickListener {

            Log.d(TAG, "rabbit")

            // Create an instance of the target fragment
            val myAnimalDetailsFragment = AnimalDetailsFragment()

            // Put the position data into the bundle with a key, then set the bundle to arguments
            val bundle = Bundle()
            bundle.putInt("position", 3)
            myAnimalDetailsFragment.arguments = bundle


            // Check the orientation to inflate the details fragment in an fragment appropriate container
            if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT){
                activity!!.supportFragmentManager.beginTransaction()
                    .replace(R.id.main_container, myAnimalDetailsFragment)
                    .addToBackStack(null)
                    .commit()
            }
            else{
                activity!!.supportFragmentManager.beginTransaction()
                    .replace(R.id.details_container, myAnimalDetailsFragment)
                    .addToBackStack(null)
                    .commit()
            }
        }

        return view
    }


}