package com.example.fragmentanimallistwithinterface


import android.os.Bundle
import android.util.Log
import android.view.Display
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_animal_details.*
import android.content.Context.*
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.fragment_animal_details.view.*


/**
 * A simple [Fragment] subclass.
 */
class AnimalDetailsFragment : Fragment() {

    private val TAG = "AnimalDetailsFragment"
    private val FILE_NAME = "MyList"

    private val ANIMAL_NAME_LIST = listOf("Dog", "Cat", "Bear", "Rabbit")

    private var ANIMAL_DETAILS = arrayOf("0","0","0","0")

    private var currentPos = 0;

    override fun onCreateView( inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment


        val view = inflater.inflate(R.layout.fragment_animal_details, container, false)
        view.saveButon.setOnClickListener {
            ANIMAL_DETAILS[currentPos] = ratingBar.rating.toString()

            // Create a SharedPreferences instance for edit
            val sharedPreferences = activity!!.getSharedPreferences(FILE_NAME,MODE_PRIVATE)
            val editor = sharedPreferences.edit()

            // save and apply changes

            editor.putString(ANIMAL_NAME_LIST[currentPos], ANIMAL_DETAILS[currentPos])
            editor.apply()

        }
        return view
    }

    override fun onStart() {
        super.onStart()

        // During startup, check if there are arguments passed to the fragment.
        // onStart is a good place to do this because the layout has already been
        // applied to the fragment at this point so we can safely call the method
        // below that sets the details.
        Log.d(TAG, "onStart")

        // Retrieve data using the key, default value is empty string in case no saved data in there



        if (arguments != null) {
            // Set details based on argument (position) passed in
            val position = arguments?.getInt("position") ?: 0
            updateDetails(position)
            currentPos = position
        }
        else{
            // Load the default position
            updateDetails(0)
        }
    }


    private fun updateDetails(position: Int) {

        // Set the text to textviews after getting the selected position
        animal_name.text = ANIMAL_NAME_LIST[position]
        val sharePref = activity!!.getSharedPreferences(FILE_NAME, MODE_PRIVATE)
        val getter = sharePref.getString(ANIMAL_NAME_LIST[position],"-") ?: "-"
        if (getter == "-") {
            ratingBar.rating = 0f
        } else {
            ANIMAL_DETAILS[position] = getter
            ratingBar.rating = ANIMAL_DETAILS[position].toFloat()
        }

        // Based on the index of position selected, set the corresponding image
        val imageId = when(position){
            0 -> R.drawable.dog
            1 -> R.drawable.cat
            2 -> R.drawable.bear
            else -> R.drawable.rabbit
        }
        animal_image.setImageResource(imageId)

    }
}
